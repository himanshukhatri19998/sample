package com.cognizant.restapicountry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestapiCountryApplicationTests {

	@Test
	void contextLoads() {
	}

}
